/*
 * AudioRenderer.cpp
 *
 *  Created on: 09-oct-2008
 *      Author: arturo castro
 */

#include "AudioRenderer.h"

namespace ofxPm{
AudioRenderer::AudioRenderer() {


}

AudioRenderer::~AudioRenderer() {

}
}
