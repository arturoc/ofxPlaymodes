/*
 * VideoSink.cpp
 *
 *  Created on: 09-oct-2008
 *      Author: arturo castro
 */

#include "VideoSink.h"

namespace ofxPm{
VideoSink::VideoSink() {


}

VideoSink::~VideoSink() {

}
}
