/*
 * VideoSource.cpp
 *
 *  Created on: 09-oct-2008
 *      Author: arturo castro
 */

#include "VideoSource.h"

namespace ofxPm{
VideoSource::VideoSource() {
	//newFrameEvent.init("PlayModes.VideoSource.newFrameEvent");

}

VideoSource::~VideoSource() {
}
}
