/*
 * AudioSource.cpp
 *
 *  Created on: 09-oct-2008
 *      Author: arturo castro
 */

#include "AudioSource.h"

namespace ofxPm{
AudioSource::AudioSource() {

}

AudioSource::~AudioSource() {

}

}
