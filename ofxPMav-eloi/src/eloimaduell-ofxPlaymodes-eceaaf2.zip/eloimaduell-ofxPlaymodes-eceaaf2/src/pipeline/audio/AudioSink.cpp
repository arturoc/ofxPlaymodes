/*
 * AudioSink.cpp
 *
 *  Created on: 09-oct-2008
 *      Author: arturo castro
 */

#include "AudioSink.h"

namespace ofxPm{
AudioSink::AudioSink() {

}

AudioSink::~AudioSink() {

}
}
