/*
 * VideoFilter.cpp
 *
 *  Created on: 19-des-2008
 *      Author: eloi
 */

#include "VideoFilter.h"

namespace ofxPm{
//----------------------------------------------------------
VideoFilter::VideoFilter() {
}


//----------------------------------------------------------
VideoFilter::~VideoFilter() {
}

}
